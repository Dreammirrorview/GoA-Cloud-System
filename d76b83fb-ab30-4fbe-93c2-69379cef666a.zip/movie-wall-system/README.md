# 🎬 Movie Wall & Wallet System

A comprehensive movie streaming platform with integrated wallet functionality, allowing users to watch movies from Netflix, Marvel, and Disney+ while earning rewards that can be transferred to local banks (Opay, Moniepoint, PalmPay).

## ✨ Features

### 🎬 Movie Wall
- Daily updates of new movies from Netflix, Marvel, and Disney+
- Beautiful grid display with movie posters
- One-click movie watching
- Automatic reward system ($100 per movie watched)

### 💰 Integrated Wallet
- Real-time wallet balance tracking
- Deposit money from bank accounts
- Withdraw to local banks (Opay, Moniepoint, PalmPay)
- Transfer between wallet and bank accounts
- Complete transaction history

### 🔐 Security Features
- Admin-only dashboard access
- Device fingerprinting (IP address, device ID, IMEI simulation)
- Cloud backup simulation for device data
- Secure transaction processing

### 📱 Device Tracking
- IP address logging
- Device name and ID tracking
- IMEI/Serial number simulation
- Owner identification (Olawale Abdul-Ganiyu)
- Cloud storage backup simulation

## 🚀 Getting Started

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn

### Installation

1. Clone or navigate to the project directory:
```bash
cd movie-wall-system
```

2. Install dependencies:
```bash
npm install
```

3. Start the server:
```bash
npm start
```

4. Access the application:
- Open your browser and go to `http://localhost:3000`

## 🔑 Admin Access

### Login Credentials
- **Username:** `admin`
- **Password:** `admin123`

### Admin Dashboard Features
- Movie management
- User monitoring
- Transaction oversight
- Device tracking review
- System settings

## 💡 Usage Guide

### Watching Movies & Earning Rewards
1. Login to the admin dashboard
2. Navigate to the "Movies" section
3. Click "Watch Now" on any movie
4. Automatically earn $100 per movie watched
5. Rewards are instantly credited to your wallet

### Wallet Operations

#### Deposit Money
1. Go to "Wallet" section
2. Click "Deposit" button
3. Select your bank (Opay, Moniepoint, or PalmPay)
4. Enter account details and amount
5. Complete the transaction

#### Withdraw Money
1. Go to "Wallet" section
2. Click "Withdraw" button
3. Select your destination bank
4. Enter account details and amount
5. Confirm the transaction

#### Transfer to Bank
1. Go to "Wallet" section
2. Click "Transfer" button
3. Select recipient bank
4. Enter recipient account details
5. Specify amount and transfer

### Transaction History
- View all transactions in the "Transactions" section
- Filter by type (deposit, withdraw, transfer, earning)
- Check transaction status and details
- View timestamps and amounts

### Device Information
- Automatic device tracking on access
- View IP address, device ID, and IMEI
- Cloud backup status monitoring
- Owner identification display

## 🏦 Supported Banks

### Opay
- Green interface
- Fast transactions
- Mobile money services

### Moniepoint
- Yellow interface
- Quick transfers
- Point of sale services

### PalmPay
- Blue interface
- Seamless transactions
- Digital wallet integration

## 📊 Database Structure

The system uses a JSON-based database with the following structure:

```json
{
  "users": [],
  "transactions": [],
  "deviceTracking": [],
  "adminCredentials": {
    "username": "admin",
    "password": "admin123"
  }
}
```

## 🔒 Security Features

### Authentication
- Admin-only access control
- Secure login system
- Session management

### Device Tracking
- IP address logging
- Device fingerprinting
- Access timestamp recording
- Owner identification

### Transaction Security
- Bank integration simulation
- Amount validation
- Account verification
- Status tracking

## 📱 Responsive Design

The application is fully responsive and works on:
- Desktop computers
- Tablets
- Mobile phones
- Various screen sizes

## 🎨 UI/UX Features

- Modern dark theme design
- Smooth animations
- Intuitive navigation
- Real-time updates
- Beautiful movie cards
- Interactive wallet interface
- Comprehensive transaction tables

## 🔧 Development

### Project Structure
```
movie-wall-system/
├── public/
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   └── app.js
│   └── index.html
├── server/
│   └── app.js
├── database/
│   └── data.json
├── config/
├── package.json
└── README.md
```

### API Endpoints

#### Authentication
- `POST /api/admin/login` - Admin login

#### Users
- `POST /api/users` - Create user
- `GET /api/users` - Get all users

#### Transactions
- `POST /api/transactions` - Create transaction
- `GET /api/transactions` - Get all transactions

#### Wallet
- `POST /api/wallet/deposit` - Deposit to wallet
- `POST /api/wallet/withdraw` - Withdraw from wallet
- `POST /api/movies/watch` - Earn rewards for watching

#### Bank Operations
- `POST /api/bank/transfer` - Transfer to bank

#### Device Tracking
- `POST /api/devices/track` - Track device access
- `GET /api/devices` - Get device information

## 📄 License Information

The system includes simulated licenses for:
- **Netflix** - Full streaming rights
- **Marvel** - Full streaming rights  
- **Disney+** - Full streaming rights

*Note: In a production environment, proper licensing agreements would be required.*

## 🚀 Deployment

For production deployment:
1. Set up a proper database (PostgreSQL, MongoDB)
2. Implement real bank API integrations
3. Add proper authentication (JWT, OAuth)
4. Set up SSL/HTTPS
5. Configure environment variables
6. Implement proper logging
7. Add monitoring and analytics

## 📞 Support

For issues or questions:
- Project Owner: Olawale Abdul-Ganiyu
- License: MIT

## 🎯 Future Enhancements

- Real movie API integration
- Live bank API connections
- User registration system
- Advanced analytics
- Movie recommendations
- Social features
- Mobile app version
- Multi-language support

---

**Built with ❤️ by SuperNinja AI Agent**